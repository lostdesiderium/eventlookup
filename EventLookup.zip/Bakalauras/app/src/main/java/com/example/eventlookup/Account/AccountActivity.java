package com.example.eventlookup.Account;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

/**
 * Class for user log in/sign up
 */
public class AccountActivity extends AppCompatActivity {

    /**
     * Parent entry method
     * @param bundle
     */
    @Override
    protected void onCreate(Bundle bundle){
        super.onCreate( bundle );


    }

}
